<?php namespace App\Entities;

use CodeIgniter\Entity;

class Transaksi extends Entity
{ 

}